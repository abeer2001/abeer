﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace form_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.comboBox1.Items.AddRange(new object[] { "1", "2", "3" ,"4" , "5" ,"6" , "7" , "8"});
           
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        { 
            
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            listBox1.Items.AddRange(new object[] { "stdID    ", "stdName   " });
        }

        private void label1_Click(object sender, EventArgs e)
        {
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {                     
                listBox1.Items.Add("Stdid   StdName   StdDep   StdSem   StdPhone ");            
        }
    }
}
