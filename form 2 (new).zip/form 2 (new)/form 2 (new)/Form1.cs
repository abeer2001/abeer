﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace form_2__new_
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.comboBoxSemester.Items.AddRange(new object[] { "1", "2", "3", "4", "5", "6", "7", "8" });
        }

        private void USNBox_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void NameBox_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void DepBox_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void comboBoxSemester_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void PhoneBox_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            string usn = USNBox.Text;
            string name = NameBox.Text;
            string depart = DepBox.Text;
            string semester = comboBoxSemester.Text;
            string phone = PhoneBox.Text;
           
            
                tableLayoutPanel1.RowCount = tableLayoutPanel1.RowCount + 1;
                tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15F));
                tableLayoutPanel1.Controls.Add(new System.Windows.Forms.Label() { Text = usn }, 0, tableLayoutPanel1.RowCount);
                tableLayoutPanel1.Controls.Add(new System.Windows.Forms.Label() { Text = name }, 1, tableLayoutPanel1.RowCount);
                tableLayoutPanel1.Controls.Add(new System.Windows.Forms.Label() { Text = depart }, 2, tableLayoutPanel1.RowCount);
                tableLayoutPanel1.Controls.Add(new System.Windows.Forms.Label() { Text = semester }, 3, tableLayoutPanel1.RowCount);
                tableLayoutPanel1.Controls.Add(new System.Windows.Forms.Label() { Text = phone }, 4, tableLayoutPanel1.RowCount);
            
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
          
            

        }

        private void buttonEdit_Click(object sender, EventArgs e)
        {
            tableLayoutPanel1.Controls.RemoveAt(2);
        }
    }
}
